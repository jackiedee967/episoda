export {StarRatings} from './StarRatings';
