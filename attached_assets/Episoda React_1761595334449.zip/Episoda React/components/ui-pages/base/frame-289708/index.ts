export {Frame289708} from './Frame289708';
